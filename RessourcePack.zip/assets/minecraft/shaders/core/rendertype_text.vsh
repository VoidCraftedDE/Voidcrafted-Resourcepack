#version 330

// VoidPack: Text-Shader aus Minecraft 1.21.11 mit einem Zusatz fuer die Dungeon-Minimap (Schrift voidpack:minimap).
// Erzeugt von VoidTexturepack/dungeon_bosses/tools/gen_minimap_pack.js - dort steht, wie es zusammenhaengt.
// Alles ausser den Zeichen dieser Schrift laeuft unveraendert durch den Originalcode.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const vec3 VOID_MAGIC = vec3(255.0, 252.0, 254.0) / 255.0;
const float VOID_MAP = 64.0;          // Kantenlaenge der Karte in Kartenpixeln
const float VOID_FRACTION = 0.22;       // ungefaehrer Anteil der Bildschirmhoehe

bool voidMagic(vec2 uv) {
    vec4 texel = texture(Sampler0, uv);
    return texel.a > 0.0 && all(lessThan(abs(texel.rgb - VOID_MAGIC), vec3(0.002)));
}

void main() {
    vec4 position = vec4(Position, 1.0);
    vec4 color = Color * texelFetch(Sampler2, UV2 / 16, 0);
    gl_Position = ProjMat * ModelViewMat * position;

    // Nur in der Oberflaeche (Parallelprojektion): gehoert die Ecke zu einem Zeichen der Minimap-Schrift?
    if (ProjMat[2][3] == 0.0 && ProjMat[3][3] == 1.0) {
        vec2 half_texel = 0.5 / vec2(textureSize(Sampler0, 0));
        if (voidMagic(UV0 + half_texel) || voidMagic(UV0 - half_texel)
                || voidMagic(UV0 + vec2(half_texel.x, -half_texel.y)) || voidMagic(UV0 + vec2(-half_texel.x, half_texel.y))) {
            // Die Textfarbe ist Nutzlast: Bits 23-18 = Zeile der Karte, darunter Rot, Gruen, Blau zu je 6 Bit
            ivec3 bytes = ivec3(round(Color.rgb * 255.0));
            int payload = (bytes.r << 16) | (bytes.g << 8) | bytes.b;
            float row = float(payload >> 18);
            vec3 tint = vec3(float((payload >> 12) & 63), float((payload >> 6) & 63), float(payload & 63)) / 63.0;

            // Wo der Client das Zeichen hinsetzen wollte: Titel einer Bossleiste, mittig, 64 Pixel breit.
            // Titelzeilen liegen bei y = 3 + 19 * n; die Zeichen haben ascent 1, ihre Oberkante liegt 6 darunter.
            vec4 gui = ModelViewMat * position;
            float gui_width = 2.0 / ProjMat[0][0];
            float title_left = floor(ceil(gui_width - 0.001) / 2.0) - VOID_MAP / 2.0;
            float below_top = mod(round(gui.y) - 9.0, 19.0);       // 0 = Oberkante, sonst die Hoehe des Zeichens (bis 16)
            vec2 local = vec2(gui.x - title_left, row + below_top);

            // Ein Kartenpixel = ganze Zahl Bildschirmpixel, so gewaehlt, dass die Karte bei jeder Aufloesung und
            // GUI-Groesse etwa denselben Anteil des Bildes einnimmt; Rand = zwei Kartenpixel.
            float screen_px = max(1.0, round(ScreenSize.y * VOID_FRACTION / VOID_MAP));
            float scale = screen_px * gui_width / ScreenSize.x;
            float margin = 2.0 * scale;
            // linke obere Ecke (User 17.11.: lieber links - rechts sitzen die Effekt-Symbole)
            gui.xy = vec2(margin + local.x * scale, margin + local.y * scale);
            gl_Position = ProjMat * gui;
            color = vec4(tint, 1.0);
        }
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = color;
    texCoord0 = UV0;
}
