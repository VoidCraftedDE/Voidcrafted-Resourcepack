#version 330

// VoidPack: Text-Shader aus Minecraft 1.21.11 mit einem Zusatz fuer die Dungeon-Minimap (Schrift voidpack:minimap).
// Erzeugt von VoidTexturepack/dungeon_bosses/tools/gen_minimap_pack.js - dort steht, wie es zusammenhaengt.
// Alles ausser den Zeichen dieser Schrift laeuft unveraendert durch den Originalcode.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const vec4 VOID_MARK = vec4(254.0, 3.0, 251.0, 9.0) / 255.0;
const float VOID_MAP = 150.0;         // Kantenlaenge der Karte in Kartenpixeln
const float VOID_CLIP = 2.0;          // Breite des Rahmens: so weit innen werden Raeume beschnitten
const float VOID_FRACTION = 0.26;      // ungefaehrer Anteil der Bildschirmhoehe
const vec3 VOID_TINT[16] = vec3[16](
    vec3(1.0000, 1.0000, 1.0000),
    vec3(0.6157, 0.4824, 1.0000),
    vec3(0.4980, 0.9137, 1.0000),
    vec3(1.0000, 0.7843, 0.3412),
    vec3(1.0000, 0.4196, 0.4196),
    vec3(0.9137, 0.8667, 1.0000),
    vec3(0.5255, 0.9373, 0.6745),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000)
);

void main() {
    vec4 position = vec4(Position, 1.0);
    vec4 color = Color * texelFetch(Sampler2, UV2 / 16, 0);
    vec2 uv = UV0;
    gl_Position = ProjMat * ModelViewMat * position;

    // Nur in der Oberflaeche (Parallelprojektion). Alle Kartenzeichen liegen uebereinander am Anfang eines Titels der
    // Breite 0 in einer Bossleisten-Zeile: ihre linke Kante steht in der Bildmitte, ihre Unterkante auf y = 10 + 19 n.
    // Daraus folgt, welche Ecke des Zeichens dieser Punkt ist - und damit, wo die Kennung in der Textur liegen muss.
    if (ProjMat[2][3] == 0.0 && ProjMat[3][3] == 1.0) {
        vec4 gui = ModelViewMat * position;
        float gui_width = 2.0 / ProjMat[0][0];
        float title_left = floor(ceil(gui_width - 0.001) / 2.0);
        bool right = gui.x > title_left + 0.5;
        bool bottom = mod(round(gui.y) - 10.0, 19.0) < 0.5;
        vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
        vec2 inward = vec2(right ? -1.0 : 1.0, bottom ? -1.0 : 1.0);
        vec4 mark = texture(Sampler0, UV0 + inward * 0.5 * texel);
        if (all(lessThan(abs(mark - VOID_MARK), vec4(0.002)))) {
            // neben der Kennung: Breite - 1, Hoehe - 1, Art des Zeichens
            vec4 info = texture(Sampler0, UV0 + vec2(inward.x * 1.5, inward.y * 0.5) * texel);
            vec2 size = floor(info.rg * 255.0 + 0.5) + 1.0;
            int kind = int(info.b * 255.0 + 0.5);
            int type = kind & 3;
            float fine = 1.0 / float(1 << ((kind >> 2) & 3));       // so viele Kartenpixel ist ein Bildpixel breit
            ivec3 bytes = ivec3(round(Color.rgb * 255.0));
            int payload = (bytes.r << 16) | (bytes.g << 8) | bytes.b;
            vec2 corner = vec2(right ? size.x : 0.0, bottom ? size.y : 0.0);
            vec2 map;
            vec3 tint = VOID_TINT[payload & 15];
            if (type >= 2) {
                // Pfeile, um ihre Mitte gedreht: der eigene in der Kartenmitte, Mitspieler an ihrem Ort
                float angle = type == 2 ? float((payload >> 12) & 4095) * (6.283185307 / 4096.0) : float(payload & 63) * (6.283185307 / 64.0);
                vec2 center = type == 2 ? vec2(VOID_MAP * 0.5) : vec2(float((payload >> 15) & 511), float((payload >> 6) & 511)) * 0.5;
                vec2 d = (corner - size * 0.5) * fine;
                map = center + vec2(d.x * cos(angle) - d.y * sin(angle), d.x * sin(angle) + d.y * cos(angle));
                if (type == 3) {
                    tint = vec3(1.0);
                }
            } else {
                // Raum, Punkt, Rahmen: Lage in halben Kartenpixeln, um 128 versetzt
                vec2 origin = vec2(float((payload >> 14) & 1023), float((payload >> 4) & 1023)) * 0.5 - 128.0;
                map = origin + corner * fine;
                if (type == 0) {
                    // an der Innenkante des Rahmens beschneiden: Ecke hereinholen, Texturstelle entsprechend mitziehen
                    vec2 inside = clamp(map, vec2(VOID_CLIP), vec2(VOID_MAP - VOID_CLIP));
                    uv += (inside - map) / fine * texel;
                    map = inside;
                }
            }
            // Ein Kartenpixel = ganze Zahl Bildschirmpixel, so gewaehlt, dass die Karte bei jeder Aufloesung und
            // GUI-Groesse etwa denselben Anteil des Bildes einnimmt; sie sitzt in der linken oberen Ecke.
            float screen_px = max(1.0, round(ScreenSize.y * VOID_FRACTION / VOID_MAP));
            float unit = gui_width / ScreenSize.x;                    // ein Bildschirmpixel in GUI-Einheiten
            float margin = max(4.0, round(ScreenSize.y * 0.012));
            gui.xy = (vec2(margin) + map * screen_px) * unit;
            gl_Position = ProjMat * gui;
            color = vec4(tint, 1.0);
        }
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = color;
    texCoord0 = uv;
}
