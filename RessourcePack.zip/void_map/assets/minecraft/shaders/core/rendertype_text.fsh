#version 330

// VoidPack: Fragment-Shader fuer Text (Original aus 1.21.11 / 26.1) mit einem Zusatz fuer die Dungeon-Minimap.
// Erzeugt von VoidTexturepack/dungeon_bosses/tools/gen_minimap_pack.js. Gehoert zu rendertype_text.vsh daneben:
// der Vertex-Shader meldet in voidRect, ob ein Kartenzeichen gezeichnet wird. Nur dann greift der Zusatz - er tastet
// das Zeichen weich ab, damit die Karte in Bruchteilen eines Bildschirmpixels gleiten kann. Aller andere Text laeuft
// durch den Originalcode.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
flat in vec4 voidRect;

out vec4 fragColor;

// Ein Texel des Kartenzeichens, Farbe mit der Deckkraft vormultipliziert. Ausserhalb des Zeichens gilt sein Randpixel
// (Nachbarzeichen liegen in der Textur direkt daneben); fast Durchsichtiges - die Kennung in den Ecken - zaehlt als leer.
vec4 void_texel(ivec2 at) {
    vec4 c = texelFetch(Sampler0, clamp(at, ivec2(voidRect.xy), ivec2(voidRect.zw) - 1), 0);
    return c.a < 0.05 ? vec4(0.0) : vec4(c.rgb * c.a, c.a);
}

// Zwischen den vier Texeln um die Stelle gemittelt (Texelmitten liegen auf n + 0.5).
vec4 void_blend(vec2 at) {
    vec2 p = at - 0.5;
    vec2 whole = floor(p);
    vec2 f = p - whole;
    ivec2 base = ivec2(whole);
    return mix(mix(void_texel(base), void_texel(base + ivec2(1, 0)), f.x),
               mix(void_texel(base + ivec2(0, 1)), void_texel(base + ivec2(1, 1)), f.x), f.y);
}

void main() {
    // Stelle in der Textur in Texeln, und wie weit ein Bildschirmpixel dort reicht (Ableitungen vor jeder Verzweigung)
    vec2 pix = texCoord0 * vec2(textureSize(Sampler0, 0));
    vec2 step_x = dFdx(pix);
    vec2 step_y = dFdy(pix);
    vec4 color;
    if (voidRect.z > voidRect.x) {
        float span = max(length(step_x), length(step_y));           // Texel je Bildschirmpixel
        vec4 c;
        if (span <= 1.05) {
            // vergroessert (Raeume): die Texel bleiben scharf, nur ihre Kanten gehen ueber einen Bildschirmpixel
            // ineinander ueber - so wandert jede Kante stufenlos statt von Pixel zu Pixel
            vec2 wide = max(abs(step_x) + abs(step_y), vec2(0.0001));
            vec2 seam = floor(pix + 0.5);
            c = void_blend(seam + clamp((pix - seam) / wide, -0.5, 0.5));
        } else {
            // verkleinert (fein gezeichnete Pfeile und Punkte): ueber die Flaeche des Bildschirmpixels mitteln
            int n = min(int(ceil(span)), 4);
            c = vec4(0.0);
            for (int j = 0; j < n; j++) {
                for (int i = 0; i < n; i++) {
                    vec2 off = (vec2(float(i), float(j)) + 0.5) / float(n) - 0.5;
                    c += void_blend(pix + step_x * off.x + step_y * off.y);
                }
            }
            c /= float(n * n);
        }
        if (c.a < 0.004) {
            discard;
        }
        color = vec4(c.rgb / c.a, c.a) * vertexColor * ColorModulator;
    } else {
        color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
        if (color.a < 0.1) {
            discard;
        }
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
