#version 330

// VoidPack: Text-Shader des Spiels (Original aus 26.1; 1.21.11 ist bis auf die Helligkeits-Zeile gleich) mit einem
// Zusatz fuer die Dungeon-Minimap (Schrift voidpack:minimap). Erzeugt von
// VoidTexturepack/dungeon_bosses/tools/gen_minimap_pack.js - dort steht, wie es zusammenhaengt.
// Liegt im Zusatzordner void_map: nur Spielversionen, fuer die er geprueft ist, bekommen ihn (pack.mcmeta, overlays).
// Alles ausser den Zeichen dieser Schrift laeuft unveraendert durch den Originalcode.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out vec4 voidRect;      // Kartenzeichen: sein Feld in der Schrift-Textur (x0, y0, x1, y1 in Texeln), sonst 0

const vec4 VOID_MARK = vec4(254.0, 3.0, 251.0, 9.0) / 255.0;
const float VOID_MAP = 150.0;         // Kantenlaenge der Karte in Kartenpixeln
const float VOID_BLOCKS = 2.0;        // Bloecke je Kartenpixel
const float VOID_CLIP = 4.0;          // Breite des Rahmens: so weit innen werden Raeume beschnitten
const float VOID_FRACTION = 0.26;      // ungefaehrer Anteil der Bildschirmhoehe
const float VOID_BIG = 240.0;         // grosse Karte: Kantenlaenge der Tafel in Einheiten
const float VOID_BIG_FRACTION = 0.72; // ihr ungefaehrer Anteil der Bildschirmhoehe
const float VOID_LABEL_RISE = 4.5;    // die Zeile mit dem Namen endet so weit ueber der Mitte des Pfeils
const vec3 VOID_TINT[16] = vec3[16](
    vec3(1.0000, 1.0000, 1.0000),
    vec3(0.6157, 0.4824, 1.0000),
    vec3(0.4980, 0.9137, 1.0000),
    vec3(1.0000, 0.7843, 0.3412),
    vec3(1.0000, 0.4196, 0.4196),
    vec3(0.9137, 0.8667, 1.0000),
    vec3(0.5255, 0.9373, 0.6745),
    vec3(0.4392, 0.4157, 0.5255),
    vec3(0.5333, 0.5098, 0.6196),
    vec3(1.0000, 0.2824, 0.2824),
    vec3(1.0000, 0.8667, 0.2745),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000)
);

void main() {
    vec4 position = vec4(Position, 1.0);
    // Helligkeit wie sample_lightmap() im Original von 26.1. In 1.21.11 steht dort texelFetch(Sampler2, UV2 / 16, 0):
    // dieselbe Stelle der Helligkeits-Textur, denn UV2 ist bei Text immer ein Vielfaches von 16.
    vec4 color = Color * texture(Sampler2, clamp((UV2 / 256.0) + 0.5 / 16.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0)));
    vec2 uv = UV0;
    gl_Position = ProjMat * ModelViewMat * position;
    voidRect = vec4(0.0);

    // Nur in der Oberflaeche (Parallelprojektion). Alle Kartenzeichen liegen uebereinander am Anfang eines Titels der
    // Breite 0 in einer Bossleisten-Zeile: ihre linke Kante steht in der Bildmitte, ihre Unterkante auf y = 10 + 19 n.
    // Daraus folgt, welche Ecke des Zeichens dieser Punkt ist - und damit, wo die Kennung in der Textur liegen muss.
    if (ProjMat[2][3] == 0.0 && ProjMat[3][3] == 1.0) {
        vec4 gui = ModelViewMat * position;
        float gui_width = 2.0 / ProjMat[0][0];
        float title_left = floor(ceil(gui_width - 0.001) / 2.0);
        vec2 tex_size = vec2(textureSize(Sampler0, 0));
        vec2 texel = 1.0 / tex_size;
        // Linke oder rechte Kante des Zeichens? Das Spiel rueckt die Texturstellen jedes Zeichens um 0,01 Bildpixel nach
        // innen (FontTexture.add): links steht also ...,01, rechts ...,99. (Nicht ueber die Lage im Bild bestimmen: ein
        // Kartenstueck darf rechts vom Titelanfang stehen - das ist seine Zusatzangabe, siehe unten.)
        bool right = fract(UV0.x * tex_size.x) > 0.5;
        bool bottom = mod(round(gui.y) - 10.0, 19.0) < 0.5;
        vec2 inward = vec2(right ? -1.0 : 1.0, bottom ? -1.0 : 1.0);
        vec4 mark = texture(Sampler0, UV0 + inward * 0.5 * texel);
        if (all(lessThan(abs(mark - VOID_MARK), vec4(0.002)))) {
            // neben der Kennung: Breite - 1, Hoehe - 1, Art des Zeichens
            vec4 info = texture(Sampler0, UV0 + vec2(inward.x * 1.5, inward.y * 0.5) * texel);
            vec2 size = floor(info.rg * 255.0 + 0.5) + 1.0;
            int kind = int(info.b * 255.0 + 0.5);
            int type = kind & 3;
            float fine = 1.0 / float(1 << ((kind >> 2) & 3));       // so viele Kartenpixel ist ein Bildpixel breit
            bool letter = (kind & 16) != 0;                         // Schrift (Namen der Mitspieler)
            ivec3 bytes = ivec3(round(Color.rgb * 255.0));
            int payload = (bytes.r << 16) | (bytes.g << 8) | bytes.b;
            vec2 corner = vec2(right ? size.x : 0.0, bottom ? size.y : 0.0);
            // das Feld des Zeichens in der Textur - der Fragment-Shader mittelt nur innerhalb davon (die Zeichen liegen
            // in der Schrift-Textur Kante an Kante)
            vec2 low = floor(UV0 * tex_size - corner + 0.5);
            voidRect = vec4(low, low + size);
            // Zusatzangabe des Stuecks: um so viele GUI-Pixel hat das Plugin es rechts vom Titelanfang gesetzt (0 = keine)
            float extra = round(gui.x - corner.x - title_left);
            float alpha = 1.0;

            // Zwei Ansichten. KLEIN: die Karte in der linken oberen Ecke, sie laeuft mit der Kamera. GROSS: die Tafel in
            // der Bildmitte mit dem ganzen aufgedeckten Dungeon, sie steht fest (das Plugin rechnet jede Lage selbst aus).
            // Gross heisst: Zusatzangabe ab 8 - bei Schrift (ihre Zusatzangabe ist der Platz in der Zeile) Bit 0 der Farbe.
            bool big = letter ? (payload & 1) != 0 : extra > 7.5;
            // Ein Kartenpixel (klein) bzw. eine Einheit der Tafel (gross) = ganze Zahl Bildschirmpixel, so gewaehlt, dass
            // Karte und Tafel bei jeder Aufloesung und GUI-Groesse etwa denselben Anteil des Bildes einnehmen.
            float px = max(1.0, round(ScreenSize.y * (big ? VOID_BIG_FRACTION / VOID_BIG : VOID_FRACTION / VOID_MAP)));
            float unit = gui_width / ScreenSize.x;                    // ein Bildschirmpixel in GUI-Einheiten
            vec2 base = big ? floor((ScreenSize - vec2(VOID_BIG * px)) * 0.5) : vec2(max(4.0, round(ScreenSize.y * 0.012)));
            float span = big ? VOID_BIG : VOID_MAP;                  // Kantenlaenge der Ansicht

            // Schrift: ein Bildpixel ist immer eine ganze Zahl Bildschirmpixel (floor(x + 0.5): round() ist bei ,5 nicht festgelegt)
            float grain = max(1.0, floor(ScreenSize.y / 1080.0 + 0.5));
            vec2 map;                                               // Stelle in der Ansicht (Kartenpixel bzw. Einheiten)
            vec3 tint = VOID_TINT[payload & 15];
            bool hide = false;
            if (type >= 2) {
                // Pfeile, um ihre Mitte gedreht
                float angle;
                vec2 center = vec2(VOID_MAP * 0.5);
                if (big) {
                    // gross: Mitte in halben Einheiten (9 + 9 Bit), Winkel in 64 Schritten - fuer beide Pfeile gleich
                    angle = float(payload & 63) * (6.283185307 / 64.0);
                    center = vec2(float((payload >> 15) & 511), float((payload >> 6) & 511)) * 0.5;
                    tint = vec3(1.0);
                } else if (type == 2) {
                    // klein: der eigene Pfeil sitzt in der Kartenmitte
                    angle = float((payload >> 12) & 4095) * (6.283185307 / 4096.0);
                } else {
                    // klein: Mitspieler an ihrem Ort in der Welt
                    angle = float(payload & 63) * (6.283185307 / 64.0);
                    ivec2 world = ivec2((payload >> 15) & 511, (payload >> 6) & 511);
                    ivec2 rel = ((world - CameraBlockPos.xz + 256) & 511) - 256;
                    center += (vec2(rel) + CameraOffset.xz) / VOID_BLOCKS;
                    float edge = VOID_CLIP + max(size.x, size.y) * fine * 0.5;
                    hide = any(lessThan(center, vec2(edge))) || any(greaterThan(center, vec2(VOID_MAP - edge)));
                    tint = vec3(1.0);
                }
                vec2 d = (corner - size * 0.5) * fine;
                map = center + vec2(d.x * cos(angle) - d.y * sin(angle), d.x * sin(angle) + d.y * cos(angle));
            } else if (type == 1) {
                // steht fest in der Ansicht (Rahmen, Hinweis): Lage in halben Kartenpixeln, um 128 versetzt
                vec2 spot = vec2(float((payload >> 14) & 1023), float((payload >> 4) & 1023)) * 0.5 - 128.0;
                map = spot + corner * fine;
                if (letter) {
                    // ein fertiges Schriftbild (der Hinweis unter der Karte): wie die Namen in ganzen Bildschirmpixeln
                    map = (floor(spot * px + 0.5) + corner * grain) / px;
                }
            } else {
                // Raum, Punkt, Schrift. Klein: Lage in der Welt (Bloecke, modulo 1024) gegen die Kamera gerechnet - die
                // genaue Kameraposition ist CameraBlockPos - CameraOffset, sie aendert sich in jedem Bild, die Karte
                // gleitet mit. Gross: Lage auf der Tafel in Viertel-Einheiten.
                vec2 spot = vec2(float((payload >> 14) & 1023), float((payload >> 4) & 1023)) * 0.25;
                if (!big) {
                    ivec2 world = ivec2((payload >> 14) & 1023, (payload >> 4) & 1023);
                    ivec2 rel = ((world - CameraBlockPos.xz + 512) & 1023) - 512;
                    spot = vec2(VOID_MAP * 0.5) + (vec2(rel) + CameraOffset.xz) / VOID_BLOCKS;
                }
                if (letter) {
                    // Schrift: die Lage ist die Mitte der Zeile (der Ort des Spielers), die Zusatzangabe minus 64 der
                    // Platz des Buchstabens in der Zeile in Bildpixeln. Ein Bildpixel der Schrift ist immer eine ganze
                    // Zahl Bildschirmpixel und sitzt auf ganzen Pixeln - sonst verschwimmen die feinen Striche. Die
                    // Zeile steht ueber dem Pfeil. Ragt ein Buchstabe ueber den Rahmen, entfaellt er.
                    vec2 at = floor(spot * px + 0.5);
                    at.x += (extra - 64.0) * grain;
                    at.y -= floor(VOID_LABEL_RISE * px + 0.5) + size.y * grain;
                    hide = at.x < VOID_CLIP * px || at.y < VOID_CLIP * px
                            || at.x + size.x * grain > (span - VOID_CLIP) * px || at.y + size.y * grain > (span - VOID_CLIP) * px;
                    map = (at + corner * grain) / px;
                    tint = vec3(1.0);
                } else {
                    float scale = fine;                             // so viele Kartenpixel bzw. Einheiten ist ein Bildpixel breit
                    if (big) {
                        // Zusatzangabe 8 bis 11: der Massstab des Dungeons (ein Kartenpixel = 2, 1, 1/2, 1/4 Einheiten);
                        // 12: Zeichen in fester Groesse (Punkte)
                        scale = extra > 11.5 ? fine : fine * exp2(9.0 - extra);
                    } else {
                        // weiches Aufdecken: die Zusatzangabe 3, 2, 1 heisst "noch drei, zwei, ein Viertel durchsichtig"
                        alpha = 1.0 - 0.25 * clamp(extra, 0.0, 3.0);
                    }
                    map = spot + corner * scale;
                    // an der Innenkante des Rahmens beschneiden: Ecke hereinholen, Texturstelle entsprechend mitziehen
                    vec2 inside = clamp(map, vec2(VOID_CLIP), vec2(span - VOID_CLIP));
                    uv += (inside - map) / scale * texel;
                    map = inside;
                }
            }
            gui.xy = (base + map * px) * unit;
            gl_Position = hide ? vec4(2.0, 2.0, 2.0, 1.0) : ProjMat * gui;
            color = vec4(tint, alpha);
        }
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = color;
    texCoord0 = uv;
}
